import React from 'react'
import  Signupc  from "../components/auth/Signupc";

const Signup = () => {
  return (
    <div>
      <Signupc />
    </div>
  )
}

export default Signup
