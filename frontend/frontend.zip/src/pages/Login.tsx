import React from 'react'
import Loginc from '../components/auth/Loginc'

const Login = () => {
  return (
    <div>
      <Loginc/>
    </div>
  )
}

export default Login
