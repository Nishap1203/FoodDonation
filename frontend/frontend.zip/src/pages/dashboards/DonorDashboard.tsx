import DonorDashboardc from '../../components/users/DonorDashboardc'

const DonorDashboard = () => {
  return (
    <div>
      <DonorDashboardc/>
    </div>
  )
}

export default DonorDashboard
