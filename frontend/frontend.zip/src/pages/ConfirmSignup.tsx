import React from 'react'
import ConfirmSignupc from '../components/auth/ConfirmSignupc'

const ConfirmSignup = () => {
  return (
    <div>
      <ConfirmSignupc/>
    </div>
  )
}

export default ConfirmSignup
