import React from 'react'
import ForgotPasswordc from '../components/auth/ForgotPasswordc'

const ForgotPassword = () => {
  return (
    <div>
      <ForgotPasswordc/>
    </div>
  )
}

export default ForgotPassword
