import RegisterNgoc from '../components/auth/RegisterNgoc';

const RegisterNgo = () => {
  return (
    <div>
      <RegisterNgoc/>
    </div>
  )
}

export default RegisterNgo
